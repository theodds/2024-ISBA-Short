#ifndef FOREST_H
#define FOREST_H

#include <RcppArmadillo.h>
#include "Node.h"

// template<typename T>
// class Tree {
//   T* root;
// };
// 
// template<typename T>
// class Forest {
//   std::vector<Tree<T>> trees; 
//   
//   Forest(int num_trees) {
//     trees.resize(0);
//     for(int t = 0; t < num_trees; t++) {
//       T* n = new T()
//     }
//   }
// };



#endif